<?php
require_once __DIR__."/../modules/Embedding.php";
require_once __DIR__."/../modules/Transformer.php";
require_once __DIR__."/../modules/SemanticGraph.php";
require_once __DIR__."/../modules/Reasoning.php";
class Evaluator {
    private $embed,$trans,$graph,$reason;
    public function __construct($vocab){
        $this->embed=new Embedding($vocab);
        $this->trans=new Transformer();
        $this->graph=new SemanticGraph();
        $this->reason=new Reasoning();
    }
    public function test($sentence){
        $vec=$this->embed->encode($sentence);
        $att=$this->trans->attention($vec);
        $tokens=explode(" ",$sentence);
        $g=$this->graph->parse($tokens);
        $inf=$this->reason->infer($g);
        return $inf;
    }
}
?>