<?php
require_once __DIR__."/../modules/Embedding.php";
require_once __DIR__."/../modules/Transformer.php";
require_once __DIR__."/../modules/SemanticGraph.php";
require_once __DIR__."/../modules/Reasoning.php";
require_once __DIR__."/../modules/MetaLearner.php";
class Trainer {
    private $embed,$trans,$graph,$reason,$meta;
    public function __construct($vocab){
        $this->embed=new Embedding($vocab);
        $this->trans=new Transformer();
        $this->graph=new SemanticGraph();
        $this->reason=new Reasoning();
        $this->meta=new MetaLearner();
    }
    public function train($dataset){
        foreach($dataset as $sample){
            $vec=$this->embed->encode($sample['text']);
            $att=$this->trans->attention($vec);
            $tokens=explode(" ",$sample['text']);
            $g=$this->graph->parse($tokens);
            $inf=$this->reason->infer($g);
            $pred=array_fill(0,count($inf),1);
            $target=array_fill(0,count($inf),1);
            $loss=$this->meta->computeLoss($pred,$target);
            echo "Trained on: ".$sample['text']." | Loss: $loss".PHP_EOL;
        }
        $this->meta->adapt();
    }
}
?>