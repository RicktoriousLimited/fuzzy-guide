<?php
require_once __DIR__."/training/Trainer.php";
require_once __DIR__."/testing/Evaluator.php";
$vocab=["boy","kicked","ball","apologized","angry","broken","phone"];
$dataset=[
    ["text"=>"the boy kicked the ball"],
    ["text"=>"the boy apologized"],
    ["text"=>"the man was angry"],
    ["text"=>"the phone was broken"]
];
$trainer = new Trainer($vocab);
$trainer->train($dataset);
$eval = new Evaluator($vocab);
$test_sentence="the boy apologized";
$results=$eval->test($test_sentence);
echo "Inference for: '$test_sentence' => ".json_encode($results).PHP_EOL;
?>