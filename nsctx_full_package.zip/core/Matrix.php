<?php
class Matrix {
    public static function dot($A, $B) {
        $res = [];
        for ($i=0;$i<count($A);$i++) {
            for ($j=0;$j<count($B[0]);$j++) {
                $sum = 0;
                for ($k=0;$k<count($B);$k++)
                    $sum += $A[$i][$k]*$B[$k][$j];
                $res[$i][$j]=$sum;
            }
        }
        return $res;
    }
    public static function add($A, $B) {
        $C = $A;
        for ($i=0;$i<count($A);$i++)
            for ($j=0;$j<count($A[0]);$j++)
                $C[$i][$j]+=$B[$i][$j];
        return $C;
    }
    public static function softmax($v) {
        $exp = array_map('exp',$v);
        $sum = array_sum($exp);
        return array_map(fn($x)=>$x/$sum,$exp);
    }
}
?>