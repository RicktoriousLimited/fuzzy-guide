<?php
require_once __DIR__."/../core/Matrix.php";
class Transformer {
    private $d;
    public function __construct($dim=64){ $this->d=$dim; }
    public function attention($X){
        $Q=$X; $K=$X; $V=$X;
        $scores = [];
        for($i=0;$i<count($Q);$i++){
            $row=[];
            for($j=0;$j<count($K);$j++){
                $dot = array_sum(array_map(fn($a,$b)=>$a*$b,$Q[$i],$K[$j]));
                $row[]=$dot/sqrt($this->d);
            }
            $scores[] = Matrix::softmax($row);
        }
        $out=[];
        for($i=0;$i<count($scores);$i++){
            $sum=array_fill(0,$this->d,0);
            foreach($scores[$i] as $j=>$w)
                foreach($V[$j] as $k=>$v) $sum[$k]+=$w*$v;
            $out[]=$sum;
        }
        return $out;
    }
}
?>