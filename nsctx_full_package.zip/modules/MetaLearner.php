<?php
class MetaLearner {
    public $lossHistory=[];
    public function computeLoss($pred,$target){
        $loss = 0;
        for($i=0;$i<count($target);$i++)
            $loss += ($pred[$i]-$target[$i])**2;
        $loss/=count($target);
        $this->lossHistory[]=$loss;
        return $loss;
    }
    public function adapt($learning_rate=0.01){
        $trend = array_sum($this->lossHistory)/count($this->lossHistory);
        echo "[Meta-Learning] Current Avg Loss: ".round($trend,4).PHP_EOL;
    }
}
?>