<?php
class Reasoning {
    private $rules=[
        'apologized'=>'feels_responsible',
        'angry'=>'cause_action',
        'broken'=>'negative_emotion'
    ];
    public function infer($graph){
        $inferences=[];
        foreach($graph as $triple){
            foreach($this->rules as $k=>$v){
                if(strpos($triple['action'],$k)!==false)
                    $inferences[]="$v(".$triple['subject'].")";
            }
        }
        return $inferences;
    }
}
?>