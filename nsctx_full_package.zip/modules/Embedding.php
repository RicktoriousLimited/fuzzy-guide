<?php
require_once __DIR__."/../core/Matrix.php";
class Embedding {
    private $embeddings = [];
    private $dim;
    public function __construct($vocab,$dim=64) {
        $this->dim=$dim;
        foreach($vocab as $word)
            $this->embeddings[$word]=array_map(fn()=>mt_rand()/mt_getrandmax(),range(1,$dim));
    }
    public function encode($sentence) {
        $tokens=explode(" ",strtolower($sentence));
        $vecs=[];
        foreach($tokens as $t)
            $vecs[]=$this->embeddings[$t]??array_fill(0,$this->dim,0);
        return $vecs;
    }
}
?>