<?php
class SemanticGraph {
    public function parse($tokens){
        $graph=[];
        for($i=0;$i<count($tokens)-2;$i++){
            $graph[]=['subject'=>$tokens[$i],'action'=>$tokens[$i+1],'object'=>$tokens[$i+2]];
        }
        return $graph;
    }
}
?>